package com.hb;

import hb.model.DocSpecialInfo;
import hb.service.DocSpecialService;
import hb.vo.DocSpecialVo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DocSpecialServiceTest {
    @Autowired
    private DocSpecialService specialService;

    @Test
    public void test() {
        DocSpecialVo specialVo=new DocSpecialVo();
        DocSpecialInfo specialInfo=new DocSpecialInfo();
        //specialService.updateSpecialInfo(specialInfo);
        //specialService.selectSpecialList(specialVo).forEach(System.out::println);
        //specialService.deleteSpecialInfo("02466528");
        //specialService.addSpecialInfo(specialInfo);
    }
    public static void main(String[] args) throws Exception {
        try{
            System.out.println(33816770&1<<4);

        }catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
