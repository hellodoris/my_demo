package hb.controller;

import com.github.pagehelper.PageInfo;
import hb.model.DocSpecialInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import hb.service.DocSpecialService;
import hb.vo.DocSpecialVo;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;


/**
 * SpringBoot controller
 * Created By PHB 18/02/25
 */
@Controller

@RequestMapping(value = "/test")
public class DocSpecialController {

    @Autowired
    private DocSpecialService specialService;

/*    @RequestMapping(method = RequestMethod.GET)
    public String user(@RequestParam(value="pageon",defaultValue="1")int pageon,Model model){
        *//*DocSpecialVo params=new DocSpecialVo();
        List<DocSpecialInfo> specialInfoList=specialService.selectSpecialList(params);
        model.addAttribute("specialInfoList",specialInfoList);*//*
        model.addAttribute("name", "Dear");
        model.addAllAttributes(specialService.selectSpecialPageList(pageon));
        model.addAttribute("date", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        return "userList";
    }*/

    // 从 application.yml 中读取配置
    @Value("${creater.name}")
    private String name;

    @RequestMapping(method = RequestMethod.GET)
    public String queryList(Model model, HttpServletRequest request, @RequestParam(required = false) Date date, @RequestParam(defaultValue = "1") Integer pageNum, @RequestParam(defaultValue = "10") Integer pageSize) {
        DocSpecialVo params=new DocSpecialVo();
        params.setSpecialNm(request.getParameter("special_nm"));
        PageInfo<DocSpecialInfo> pageInfo = specialService.selectSpecialList(params, pageNum, pageSize);
        //获得当前页
        model.addAttribute("pageNum", pageInfo.getPageNum());
        //获得一页显示的条数
        model.addAttribute("pageSize", pageInfo.getPageSize());
        //是否是第一页
        model.addAttribute("isFirstPage", pageInfo.isIsFirstPage());
        //获得总页数
        model.addAttribute("totalPages", pageInfo.getPages());
        //是否是最后一页
        model.addAttribute("isLastPage", pageInfo.isIsLastPage());
        model.addAttribute("specialInfoList", pageInfo.getList());
        model.addAttribute("name", name);
        model.addAttribute("date", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        return "specialList";
    }

    @ResponseBody
    @RequestMapping(value = {"/del"})
    public String delete(Model model,HttpServletRequest request) {
        String specialId=request.getParameter("specialId");
        specialService.delDocSpecialInfo(specialId);
        return "200";
    }
/*    @PostMapping("/list")
    public PageInfo<DocSpecialInfo> list(@RequestBody DocSpecialVo params) {
        return specialService.selectSpecialList(params);
    }*/

    @RequestMapping(value = {"/", "/view"})
    public String view(Map<String, Object> map) {
        map.put("name", name);
        map.put("date", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        return "index";
    }

}
