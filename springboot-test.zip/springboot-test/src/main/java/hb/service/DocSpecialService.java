package hb.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import hb.dao.DocSpecialMapper;
import hb.model.DocSpecialInfo;
import hb.model.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import hb.vo.DocSpecialVo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class DocSpecialService {

    @Autowired
    private DocSpecialMapper specialMapper;

    //列表查询
    public PageInfo<DocSpecialInfo> selectSpecialList(DocSpecialVo params,Integer page,Integer pageSize) {
        PageHelper.startPage(page, pageSize);
        return new PageInfo<>(specialMapper.selectDocSpecialList(params));
    }

    //分页列表查询
    public Map<String, Object> selectSpecialPageList(int pageon) {
        // TODO Auto-generated method stub
        Map<String,Object> map=new HashMap<String, Object>();
        Page page=new Page(pageon);
        int pageNum=specialMapper.selectPageListCount(null);
        page.setRowcountAndCompute(pageNum);
        map.put("page", page);
        map.put("specialInfoList", specialMapper.selectPageList(map));
        return map;
    }
    //删除
    public void delDocSpecialInfo(String specialId){
        specialMapper.deleteSpecialInfo(specialId);
    }
    public DocSpecialInfo selectDocSpecialByNm(String specialNm) {
        /*PageHelper.startPage(params.getPageNum(), params.getPageSize());*/
        DocSpecialInfo specialInfoList=specialMapper.selectDocSpecialByNm(specialNm);
        return specialInfoList;
    }
}
