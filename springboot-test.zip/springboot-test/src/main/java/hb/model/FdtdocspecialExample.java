package hb.model;

import java.util.ArrayList;
import java.util.List;

public class FdtdocspecialExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public FdtdocspecialExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andSpecialIdIsNull() {
            addCriterion("SPECIAL_ID is null");
            return (Criteria) this;
        }

        public Criteria andSpecialIdIsNotNull() {
            addCriterion("SPECIAL_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSpecialIdEqualTo(String value) {
            addCriterion("SPECIAL_ID =", value, "specialId");
            return (Criteria) this;
        }

        public Criteria andSpecialIdNotEqualTo(String value) {
            addCriterion("SPECIAL_ID <>", value, "specialId");
            return (Criteria) this;
        }

        public Criteria andSpecialIdGreaterThan(String value) {
            addCriterion("SPECIAL_ID >", value, "specialId");
            return (Criteria) this;
        }

        public Criteria andSpecialIdGreaterThanOrEqualTo(String value) {
            addCriterion("SPECIAL_ID >=", value, "specialId");
            return (Criteria) this;
        }

        public Criteria andSpecialIdLessThan(String value) {
            addCriterion("SPECIAL_ID <", value, "specialId");
            return (Criteria) this;
        }

        public Criteria andSpecialIdLessThanOrEqualTo(String value) {
            addCriterion("SPECIAL_ID <=", value, "specialId");
            return (Criteria) this;
        }

        public Criteria andSpecialIdLike(String value) {
            addCriterion("SPECIAL_ID like", value, "specialId");
            return (Criteria) this;
        }

        public Criteria andSpecialIdNotLike(String value) {
            addCriterion("SPECIAL_ID not like", value, "specialId");
            return (Criteria) this;
        }

        public Criteria andSpecialIdIn(List<String> values) {
            addCriterion("SPECIAL_ID in", values, "specialId");
            return (Criteria) this;
        }

        public Criteria andSpecialIdNotIn(List<String> values) {
            addCriterion("SPECIAL_ID not in", values, "specialId");
            return (Criteria) this;
        }

        public Criteria andSpecialIdBetween(String value1, String value2) {
            addCriterion("SPECIAL_ID between", value1, value2, "specialId");
            return (Criteria) this;
        }

        public Criteria andSpecialIdNotBetween(String value1, String value2) {
            addCriterion("SPECIAL_ID not between", value1, value2, "specialId");
            return (Criteria) this;
        }

        public Criteria andSpecialNmIsNull() {
            addCriterion("SPECIAL_NM is null");
            return (Criteria) this;
        }

        public Criteria andSpecialNmIsNotNull() {
            addCriterion("SPECIAL_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSpecialNmEqualTo(String value) {
            addCriterion("SPECIAL_NM =", value, "specialNm");
            return (Criteria) this;
        }

        public Criteria andSpecialNmNotEqualTo(String value) {
            addCriterion("SPECIAL_NM <>", value, "specialNm");
            return (Criteria) this;
        }

        public Criteria andSpecialNmGreaterThan(String value) {
            addCriterion("SPECIAL_NM >", value, "specialNm");
            return (Criteria) this;
        }

        public Criteria andSpecialNmGreaterThanOrEqualTo(String value) {
            addCriterion("SPECIAL_NM >=", value, "specialNm");
            return (Criteria) this;
        }

        public Criteria andSpecialNmLessThan(String value) {
            addCriterion("SPECIAL_NM <", value, "specialNm");
            return (Criteria) this;
        }

        public Criteria andSpecialNmLessThanOrEqualTo(String value) {
            addCriterion("SPECIAL_NM <=", value, "specialNm");
            return (Criteria) this;
        }

        public Criteria andSpecialNmLike(String value) {
            addCriterion("SPECIAL_NM like", value, "specialNm");
            return (Criteria) this;
        }

        public Criteria andSpecialNmNotLike(String value) {
            addCriterion("SPECIAL_NM not like", value, "specialNm");
            return (Criteria) this;
        }

        public Criteria andSpecialNmIn(List<String> values) {
            addCriterion("SPECIAL_NM in", values, "specialNm");
            return (Criteria) this;
        }

        public Criteria andSpecialNmNotIn(List<String> values) {
            addCriterion("SPECIAL_NM not in", values, "specialNm");
            return (Criteria) this;
        }

        public Criteria andSpecialNmBetween(String value1, String value2) {
            addCriterion("SPECIAL_NM between", value1, value2, "specialNm");
            return (Criteria) this;
        }

        public Criteria andSpecialNmNotBetween(String value1, String value2) {
            addCriterion("SPECIAL_NM not between", value1, value2, "specialNm");
            return (Criteria) this;
        }

        public Criteria andSpecialRmkIsNull() {
            addCriterion("SPECIAL_RMK is null");
            return (Criteria) this;
        }

        public Criteria andSpecialRmkIsNotNull() {
            addCriterion("SPECIAL_RMK is not null");
            return (Criteria) this;
        }

        public Criteria andSpecialRmkEqualTo(String value) {
            addCriterion("SPECIAL_RMK =", value, "specialRmk");
            return (Criteria) this;
        }

        public Criteria andSpecialRmkNotEqualTo(String value) {
            addCriterion("SPECIAL_RMK <>", value, "specialRmk");
            return (Criteria) this;
        }

        public Criteria andSpecialRmkGreaterThan(String value) {
            addCriterion("SPECIAL_RMK >", value, "specialRmk");
            return (Criteria) this;
        }

        public Criteria andSpecialRmkGreaterThanOrEqualTo(String value) {
            addCriterion("SPECIAL_RMK >=", value, "specialRmk");
            return (Criteria) this;
        }

        public Criteria andSpecialRmkLessThan(String value) {
            addCriterion("SPECIAL_RMK <", value, "specialRmk");
            return (Criteria) this;
        }

        public Criteria andSpecialRmkLessThanOrEqualTo(String value) {
            addCriterion("SPECIAL_RMK <=", value, "specialRmk");
            return (Criteria) this;
        }

        public Criteria andSpecialRmkLike(String value) {
            addCriterion("SPECIAL_RMK like", value, "specialRmk");
            return (Criteria) this;
        }

        public Criteria andSpecialRmkNotLike(String value) {
            addCriterion("SPECIAL_RMK not like", value, "specialRmk");
            return (Criteria) this;
        }

        public Criteria andSpecialRmkIn(List<String> values) {
            addCriterion("SPECIAL_RMK in", values, "specialRmk");
            return (Criteria) this;
        }

        public Criteria andSpecialRmkNotIn(List<String> values) {
            addCriterion("SPECIAL_RMK not in", values, "specialRmk");
            return (Criteria) this;
        }

        public Criteria andSpecialRmkBetween(String value1, String value2) {
            addCriterion("SPECIAL_RMK between", value1, value2, "specialRmk");
            return (Criteria) this;
        }

        public Criteria andSpecialRmkNotBetween(String value1, String value2) {
            addCriterion("SPECIAL_RMK not between", value1, value2, "specialRmk");
            return (Criteria) this;
        }

        public Criteria andSpecialStsIsNull() {
            addCriterion("SPECIAL_STS is null");
            return (Criteria) this;
        }

        public Criteria andSpecialStsIsNotNull() {
            addCriterion("SPECIAL_STS is not null");
            return (Criteria) this;
        }

        public Criteria andSpecialStsEqualTo(String value) {
            addCriterion("SPECIAL_STS =", value, "specialSts");
            return (Criteria) this;
        }

        public Criteria andSpecialStsNotEqualTo(String value) {
            addCriterion("SPECIAL_STS <>", value, "specialSts");
            return (Criteria) this;
        }

        public Criteria andSpecialStsGreaterThan(String value) {
            addCriterion("SPECIAL_STS >", value, "specialSts");
            return (Criteria) this;
        }

        public Criteria andSpecialStsGreaterThanOrEqualTo(String value) {
            addCriterion("SPECIAL_STS >=", value, "specialSts");
            return (Criteria) this;
        }

        public Criteria andSpecialStsLessThan(String value) {
            addCriterion("SPECIAL_STS <", value, "specialSts");
            return (Criteria) this;
        }

        public Criteria andSpecialStsLessThanOrEqualTo(String value) {
            addCriterion("SPECIAL_STS <=", value, "specialSts");
            return (Criteria) this;
        }

        public Criteria andSpecialStsLike(String value) {
            addCriterion("SPECIAL_STS like", value, "specialSts");
            return (Criteria) this;
        }

        public Criteria andSpecialStsNotLike(String value) {
            addCriterion("SPECIAL_STS not like", value, "specialSts");
            return (Criteria) this;
        }

        public Criteria andSpecialStsIn(List<String> values) {
            addCriterion("SPECIAL_STS in", values, "specialSts");
            return (Criteria) this;
        }

        public Criteria andSpecialStsNotIn(List<String> values) {
            addCriterion("SPECIAL_STS not in", values, "specialSts");
            return (Criteria) this;
        }

        public Criteria andSpecialStsBetween(String value1, String value2) {
            addCriterion("SPECIAL_STS between", value1, value2, "specialSts");
            return (Criteria) this;
        }

        public Criteria andSpecialStsNotBetween(String value1, String value2) {
            addCriterion("SPECIAL_STS not between", value1, value2, "specialSts");
            return (Criteria) this;
        }

        public Criteria andTmSmpIsNull() {
            addCriterion("TM_SMP is null");
            return (Criteria) this;
        }

        public Criteria andTmSmpIsNotNull() {
            addCriterion("TM_SMP is not null");
            return (Criteria) this;
        }

        public Criteria andTmSmpEqualTo(String value) {
            addCriterion("TM_SMP =", value, "tmSmp");
            return (Criteria) this;
        }

        public Criteria andTmSmpNotEqualTo(String value) {
            addCriterion("TM_SMP <>", value, "tmSmp");
            return (Criteria) this;
        }

        public Criteria andTmSmpGreaterThan(String value) {
            addCriterion("TM_SMP >", value, "tmSmp");
            return (Criteria) this;
        }

        public Criteria andTmSmpGreaterThanOrEqualTo(String value) {
            addCriterion("TM_SMP >=", value, "tmSmp");
            return (Criteria) this;
        }

        public Criteria andTmSmpLessThan(String value) {
            addCriterion("TM_SMP <", value, "tmSmp");
            return (Criteria) this;
        }

        public Criteria andTmSmpLessThanOrEqualTo(String value) {
            addCriterion("TM_SMP <=", value, "tmSmp");
            return (Criteria) this;
        }

        public Criteria andTmSmpLike(String value) {
            addCriterion("TM_SMP like", value, "tmSmp");
            return (Criteria) this;
        }

        public Criteria andTmSmpNotLike(String value) {
            addCriterion("TM_SMP not like", value, "tmSmp");
            return (Criteria) this;
        }

        public Criteria andTmSmpIn(List<String> values) {
            addCriterion("TM_SMP in", values, "tmSmp");
            return (Criteria) this;
        }

        public Criteria andTmSmpNotIn(List<String> values) {
            addCriterion("TM_SMP not in", values, "tmSmp");
            return (Criteria) this;
        }

        public Criteria andTmSmpBetween(String value1, String value2) {
            addCriterion("TM_SMP between", value1, value2, "tmSmp");
            return (Criteria) this;
        }

        public Criteria andTmSmpNotBetween(String value1, String value2) {
            addCriterion("TM_SMP not between", value1, value2, "tmSmp");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}