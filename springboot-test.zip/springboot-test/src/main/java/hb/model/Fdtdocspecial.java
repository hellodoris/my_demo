package hb.model;

public class Fdtdocspecial {
    private String specialId;

    private String specialNm;

    private String specialRmk;

    private String specialSts;

    private String tmSmp;

    public String getSpecialId() {
        return specialId;
    }

    public void setSpecialId(String specialId) {
        this.specialId = specialId == null ? null : specialId.trim();
    }

    public String getSpecialNm() {
        return specialNm;
    }

    public void setSpecialNm(String specialNm) {
        this.specialNm = specialNm == null ? null : specialNm.trim();
    }

    public String getSpecialRmk() {
        return specialRmk;
    }

    public void setSpecialRmk(String specialRmk) {
        this.specialRmk = specialRmk == null ? null : specialRmk.trim();
    }

    public String getSpecialSts() {
        return specialSts;
    }

    public void setSpecialSts(String specialSts) {
        this.specialSts = specialSts == null ? null : specialSts.trim();
    }

    public String getTmSmp() {
        return tmSmp;
    }

    public void setTmSmp(String tmSmp) {
        this.tmSmp = tmSmp == null ? null : tmSmp.trim();
    }
}