package hb.dao;

import hb.model.DocSpecialInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import hb.vo.DocSpecialVo;

import java.util.List;
import java.util.Map;

@Mapper
public interface DocSpecialMapper{
    @Select({"select '1' || lpad(seq_user_id.nextval,7,'0') from dual"})
    String selectSeqId();
    List<DocSpecialInfo> selectDocSpecialList(DocSpecialVo params);

    DocSpecialInfo selectDocSpecialByNm(String specialNm);

    List<DocSpecialInfo> selectPageList(Map map);

    int selectPageListCount(Map map);

    public void addSpecialInfo(DocSpecialInfo params);

    public void updateSpecialInfo(DocSpecialVo params);

    public void deleteSpecialInfo(String specialId);
}
