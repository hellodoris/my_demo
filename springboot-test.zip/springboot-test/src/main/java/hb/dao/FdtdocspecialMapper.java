package hb.dao;

import java.util.List;
import hb.model.Fdtdocspecial;
import hb.model.FdtdocspecialExample;
import org.apache.ibatis.annotations.Param;

public interface FdtdocspecialMapper {
    int countByExample(FdtdocspecialExample example);

    int deleteByExample(FdtdocspecialExample example);

    int deleteByPrimaryKey(String specialId);

    int insert(Fdtdocspecial record);

    int insertSelective(Fdtdocspecial record);

    List<Fdtdocspecial> selectByExample(FdtdocspecialExample example);

    Fdtdocspecial selectByPrimaryKey(String specialId);

    int updateByExampleSelective(@Param("record") Fdtdocspecial record, @Param("example") FdtdocspecialExample example);

    int updateByExample(@Param("record") Fdtdocspecial record, @Param("example") FdtdocspecialExample example);

    int updateByPrimaryKeySelective(Fdtdocspecial record);

    int updateByPrimaryKey(Fdtdocspecial record);
}