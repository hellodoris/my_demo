package hb.vo;


import hb.model.DocSpecialInfo;

/**
 * 医生擅长信息
 */
public class DocSpecialVo extends DocSpecialInfo {
    private String specialOldNm;

    public String getSpecialOldNm() {
        return specialOldNm;
    }

    public void setSpecialOldNm(String specialOldNm) {
        this.specialOldNm = specialOldNm;
    }
}
